export const SobreNosotros = () => {
  return (
    <>
      <div className="SobreNosotros">

        <img className="d-block w-100" src="https://www.economiadigital.es/wp-content/uploads/2020/10/taller-costura-inditex-arteixo-59241.jpg"></img>
        
        <h3 className="text-decoration">
          Nuestro compromiso es ofrecer una gran variedad de prendas con una
          excelente relación diseño-precio-calidad.
        </h3>
        <h3 className="text-decoration">
          Trabajamos para tener una constante renovación de productos, lo que
          nos ayuda a brindarle a nuestros clientes una gran diversidad de
          prendas de moda para que pueda usar en diferentes momentos del día.{" "}
        </h3>
        <div className="text-h1">
        <h1>Nuestros Valores:</h1>
        <h3>Cliente siempre primero</h3>
        <h3>Compromiso</h3>
        <h3>Pasión</h3>
        <h3>Hacer lo correcto</h3>
        <h3>Más que un equipo</h3>
        <h3>Innovación</h3>
        <h3>Comunicación</h3>
      </div>
      </div>
    </>
  );
};
